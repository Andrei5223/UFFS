import React from "react";

function SubTitulo(props) {
    return (
        <h2>{props.mensagem}</h2>
    )
}

export default SubTitulo;