import React from "react";

function Titulo(props) {
    return (
        <h1>{props.mensagem}</h1>
    )
}

export default Titulo;